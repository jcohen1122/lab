import time

def show_time():
    print("Current time is:", time.ctime())